import React from 'react';
import { Card, Row, Col } from 'react-bootstrap';
const PropertyInterestedPage = () => {
  return (
    <>
      <Card>
        <Card.Body>
          <Row>
            <Col>
              <p>Interesados Page</p>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </>
  );
};
export default PropertyInterestedPage;
